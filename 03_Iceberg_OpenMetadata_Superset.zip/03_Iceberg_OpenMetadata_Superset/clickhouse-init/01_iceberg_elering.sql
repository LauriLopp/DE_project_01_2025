DROP VIEW IF EXISTS bronze_elering_price_iceberg;

CREATE VIEW bronze_elering_price_iceberg AS
SELECT *
FROM iceberg(
  'http://minio:9000/warehouse/bronze.db/elering_price_iceberg',
  'admin',
  'password'
);