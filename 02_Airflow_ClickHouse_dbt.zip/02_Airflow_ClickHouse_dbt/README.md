# ⚙️ Part 2 — Data Pipeline with Airflow, dbt, and ClickHouse

This stage extends the project into a **fully automated data engineering pipeline**, integrating **Airflow**, **dbt**, and **ClickHouse**.  
The goal is to orchestrate data ingestion, transformation, and storage for the analytical data warehouse designed in Part 1.

---

## Overview

---

## 🧱 Components


---

## 🗂️ Data Flow



---